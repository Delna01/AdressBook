#include <stdio.h>
#include "file.h"

void save_contacts(AddressBook* addressBook) 
{
    FILE* fp;
    fp = fopen("contacts.txt", "w");
    
    fprintf(fp, "#%d\n", addressBook->contactCount); 
    for (int i = 0; i < addressBook->contactCount;i++)
    {
        Contact* c = &addressBook->contacts[i];
        fprintf(fp, "%s,%s,%s\n", c->name, c->phone, c->email);
    }
    fclose(fp);
    return;
}

void load_contacts(AddressBook* addressBook)
{
    FILE* fp;
    fp = fopen("contacts.txt", "r"); 
    if (fp == NULL) 
    {
        printf("Error! File doesnot exist");
        return;
    }
    fscanf(fp, "#%d\n", &addressBook->contactCount); 
    for (int i = 0; i < addressBook->contactCount;i++)
    {
        Contact* c = &addressBook->contacts[i];
        fscanf(fp, "%[^,],%[^,],%[^\n]\n", c->name, c->phone, c->email); 
    }
    fclose(fp);
    return;
}