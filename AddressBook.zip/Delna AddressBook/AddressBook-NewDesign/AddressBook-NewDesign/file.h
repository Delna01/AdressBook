#ifndef FILE_H
#define FILE_H

#include "contact.h"

void save_contacts(AddressBook* addressBook);
void load_contacts(AddressBook* addressBook);

#endif