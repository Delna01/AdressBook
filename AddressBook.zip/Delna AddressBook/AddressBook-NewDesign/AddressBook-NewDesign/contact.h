#ifndef CONTACT_H
#define CONTACT_H

#define MAX_CONTACTS 100

typedef struct {
    char name[50];
    char phone[20];
    char email[50];
} Contact;

typedef struct {
    Contact contacts[100];
    int contactCount;
} AddressBook;
int name_validate(char *name);
int number_validate(char *phone);
int email_validate(char *email);
int searchandselectContact(AddressBook *addressBook,int choice) ;
int phone_duplicate(AddressBook*addressBook,char *);
int email_duplicate(AddressBook*addressBook,char *);
void createContact(AddressBook *addressBook);
void searchContact(AddressBook *addressBook);
void editContact(AddressBook *addressBook);
void deleteContact(AddressBook *addressBook);
void listContacts(AddressBook *addressBook);
void initialize(AddressBook *addressBook);
void save_contacts(AddressBook* addressBook);
void load_contacts(AddressBook* addressBook);

#endif
