#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "contact.h"

int asktocontinue(char *operation)
{
    char response;
    printf("\nDo you want to %s again? (y/n): ", operation);
    scanf(" %c",&response);
    getchar(); 
    return (response == 'y' || response == 'Y');
}
int name_validate(char *name)
{
    int i=0;
   while(name[i]!='\0')
   {
    if(!((name[i]>='A'&&name[i]<='Z')||(name[i]>='a'&&name[i]<='z')||name[i]==' '))
    {
        printf("Invalid Name\nOnly alphabets and spaces are allowed\n");
        return 0;
    }
    if(!(name[0]>='A'&&name[0]<='Z'))
    {
        printf("Invalid name first letter must be uppercase!\n");
        return 0;
    }
    i++;
   }
   return 1;
}
int number_validate(char *phone)
{
   if(strlen(phone)!=10)
   {
    printf("Invalid Mobile number!Must be 10 digits.\n");
    return 0;
   }
   for(int i=0;i<10;i++)
   {
    if(!(phone[i]>='0'&&phone[i]<='9'))
    {
        printf("Invalid mobile number!only digits alloweded");
        return 0;
    }
    if(!(phone[0]=='6'||phone[0]=='7'||phone[0]=='8'||phone[0]=='9'))
    {
        printf("Invalid mobile number");
        return 0;
    }
   }
   return 1;
}
int email_validate(char *email)
{
    int atindex = -1, dotindex = -1;
    int len = strlen(email);
    
    if (len == 0 || len > 30)
    {
        printf("Invalid Mail id! Length exceeded the limit.\n");
        return 0;
    }
    
    
    for (int i = 0; i < len; i++)
    {
        char c = email[i];

       
        if (!(islower(c) || isdigit(c) || c == '@' || c == '.' || c == '_' || c == '-'))
        {
            printf("Invalid Mail id! Only lowercase letters, digits, '@', '.', '_' and '-' are allowed.\n");
            return 0;
        }
        if (c == ' ')
        {
            printf("Invalid Mail id! Spaces are not allowed.\n");
            return 0;
        }
    }
    
    
    int atcount = 0;
    for (int i = 0; i < len; i++)
    {
        if (email[i] == '@')
        {
            atindex = i;
            atcount++;
        }
    }
    
    if (atcount != 1)
    {
        printf("Invalid Mail id! There should be exactly one '@'.\n");
        return 0;
    }
    
    if (atindex == 0 || atindex == len - 1)
    {
        printf("Invalid Mail id! '@' cannot be at start or end.\n");
        return 0;
    }
    
    
    int dot_after_at = 0;
    for (int i = atindex + 1; i < len; i++)
    {
        if (email[i] == '.')
        {
            dot_after_at = 1;
            dotindex = i;
            break;
        }
    }
    
    if (!dot_after_at)
    {
        printf("Invalid Mail id! There should be at least one '.' after '@'.\n");
        return 0;
    }
    
    
    if (dotindex - atindex <= 1)
    {
        printf("Invalid Mail id! There should be something between '@' and '.'.\n");
        return 0;
    }
    
   
    int last_dot_index = -1;
    for (int i = len - 1; i > atindex; i--)
    {
        if (email[i] == '.')
        {
            last_dot_index = i;
            break;
        }
    }
    
    if (last_dot_index == len - 1)
    {
        printf("Invalid Mail id! There should be something after the last '.'.\n");
        return 0;
    }
    
    
    return 1;
}

int phone_duplicate(AddressBook *addressBook, char *phone)
{
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if(strcmp(addressBook->contacts[i].phone,phone)==0)
        {
            printf("The number is already exit!\n");
            return 1;
        }
    }
    return 0;
}

int email_duplicate(AddressBook *addressBook, char *email)
{
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if(strcmp(addressBook->contacts[i].email,email)==0)
        {
            printf("The Email id is already exit!\n");
            return 1;
        }
    }
    return 0;
}

int searchandselectContact(AddressBook *addressBook,int choice) 
{
    
    int flag=0;
    char searchTerm[100];
   int index[100];
   int count=0;
   switch (choice)
    {
    case 1:
    {
        char name1[100];
        while(1)
        {
        printf("Enter the name :");
        scanf(" %[^\n]",name1);
        getchar();
       for(int i = 0 ; i < addressBook->contactCount ; i++)
        {
            
            if(strcmp(addressBook->contacts[i].name,name1)==0)
            {
                if(count==0)
                {
                    printf("\nContact(s) found:\n");
                    printf("Index\tName\t\tMobile Number\tEmail\n");
                    printf("-----\t----\t\t-------------\t-----\n");
                }
                
                 printf("%d\t%s\t%s\t%s\n", count + 1, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
                index[count]=i;
                count++;
                flag=1;
            }
        }
        if(count>0)
        {
            int num;
            printf("\nEnter the number of the contact to select (1-%d): ", count);
            scanf("%d", &num);
            if(num>=1 && num<=count)
            {
                int selectindex=index[num-1];
            

                    return selectindex;
                } 
               else
               {
                printf("Invalid selection!\n");
                    
               } 
        }
        else
        {
            printf("Contact not found. Please enter again.\n");
        }
    }
}

    

        
    case 2:
    {
        char phone1[100];
        while(1)
        {
        printf("Enter the Mobile Number :");
        scanf("%s",phone1);
        getchar();
        for(int i = 0 ; i <addressBook->contactCount ; i++)
        {
            
            if(strcmp(addressBook->contacts[i].phone,phone1)==0)
            {
                printf("contact found\n");
                printf("Index\tName\t\tMobile Number\tEmail\n");
                printf("-----\t----\t\t-------------\t-----\n");
                printf("%d\t%s\t%s\t%s\n", 1, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
                count++;
                return i;
                
            }
        }
        if (flag==0)
        {
            printf("Contact not found. Please try again.\n");
        }
     
    }
}
    case 3:
    {
        char email1[100];
        while(1)
        {
        printf("Enter the Email ID :");
        scanf("%s",email1);
        getchar();
        for(int i = 0 ; i <addressBook->contactCount ; i++)
        {
           
            if(strcmp(addressBook->contacts[i].email,email1)==0)
            {
                printf("contact found\n");
                printf("Index\tName\t\tMobile Number\tEmail\n");
                printf("-----\t----\t\t-------------\t-----\n");
                printf("%d\t%s\t%s\t%s\n", 1, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
               return i;
               
            }
        } 
    if(flag==0)
    {
        printf("contact not found\n");
        
    }
}
 }
}
}
void listContacts(AddressBook *addressBook) 
{
 if(addressBook->contactCount == 0)
    {
        printf("No contacts in address book!\n");
        return;
    }
    
   for(int i = 0; i < addressBook->contactCount - 1; i++)
    {
        for(int j = 0; j < addressBook->contactCount - i - 1; j++)
        {
            if(strcmp(addressBook->contacts[j].name, addressBook->contacts[j + 1].name) > 0)
            {
                
                Contact temp =addressBook->contacts[j] ;
                addressBook->contacts[j] = addressBook->contacts[j+1];
                 addressBook->contacts[j+1]= temp;
            }
        }
    }



    printf("\nContact List:\n");
    printf("%-5s %-15s %-15s %-25s\n", "Index", "Name", "Mobile Number", "Email");
    printf("%-5s %-15s %-15s %-25s\n", "-----", "----", "-------------", "-----");
    for(int i = 0 ; i <addressBook->contactCount ; i++)
    {
         printf("%-5d %-15s %-15s %-25s\n", 
               i + 1, 
               addressBook->contacts[i].name, 
               addressBook->contacts[i].phone, 
               addressBook->contacts[i].email);
    }
   if(asktocontinue("List Contact:"))
    {
       listContacts(addressBook);
    }
    else
    {
        printf("Returning to main menu...\n");
    }
    
}


void initialize(AddressBook *addressBook) {
    addressBook->contactCount = 0;
    load_contacts(addressBook);
    
    // Load contacts from file during initialization (After files)
    //loadContactsFromFile(addressBook);
}




void createContact(AddressBook *addressBook)
{
Contact *c = &addressBook->contacts[addressBook->contactCount]; 
    printf("Enter the name: ");
    scanf(" %[^\n]", c->name);
    while(!(name_validate(c->name)))
    {
        printf("Enter the name: ");
        scanf(" %[^\n]", c->name);
    }
    
    printf("Enter the mobile number: ");
    scanf("%s", c->phone);
    while(!(number_validate(c->phone))||phone_duplicate(addressBook, c->phone))
    {
       printf("Enter the mobile number: ");
       scanf("%s", c->phone);
    }
    printf("Enter the Email id: ");
    scanf("%s", c->email);
    while(!(email_validate(c->email))||email_duplicate(addressBook, c->email)) 
    {
    printf("Enter the Email id: ");
    scanf("%s", c->email);
    }
   
    addressBook->contactCount++;
    
    
    printf("Contact added successfully!\n");
    
      if(asktocontinue("Create contact:"))
    {
        createContact(addressBook);
    }
    else
    {
        printf("Returning to main menu...\n");
    }
}

     


void searchContact(AddressBook *addressBook) 
{
    int option;
    printf("Search by: 1-Name, 2-Phone, 3-Email: ");
    scanf(" %d",&option);
    getchar();
    if(option < 1 || option > 3) {
        printf("Invalid option\n");
        return;
    }
    
    int index = searchandselectContact(addressBook, option);
    
    if(index != -1) 
    {
        printf("\n=== Selected Contact Details ===\n");
        printf("Index\t: %d\n", index + 1);
        printf("Name: %s\n", addressBook->contacts[index].name);
        printf("Mobile Number: %s\n", addressBook->contacts[index].phone);
        printf("Email Id: %s\n", addressBook->contacts[index].email);
        printf("===============================\n");
    }
     if(asktocontinue("Search contact:"))
    {
        searchContact(addressBook);
    }
    else
    {
        printf("Returning to main menu...\n");
    }
}

   

void editContact(AddressBook *addressBook)
{
    int option;
    char searchTerm[100];
    char editname[100];
    char editphone[100];
    char editemail[100];
    printf("Search contact to edit by: 1-Name, 2-Phone, 3-Email: ");
    scanf("%d", &option);
    getchar(); 
    if(option<1 || option>3)
    {
        printf("Invalid option\n");
        return;
    }
    int index = searchandselectContact(addressBook, option);
    if(index == -1) {
        printf("Contact not found.\n");
        return;
    }
    
    printf("\nCurrent contact details:\n");
    printf("Name: %s\n", addressBook->contacts[index].name);
    printf("Phone: %s\n", addressBook->contacts[index].phone);
    printf("Email: %s\n", addressBook->contacts[index].email);

    
  
    int editOption;
    printf("\nWhat would you like to edit?\n");
    printf("1. Name only\n");
    printf("2. Phone only\n");
    printf("3. Email only\n");
    printf("4. All fields\n");
    printf("Enter your choice: ");
    scanf("%d", &editOption);
    getchar();
    Contact *c = &addressBook->contacts[index];  
    
   
    switch(editOption)
    {
        case 1:
            printf("Enter new name: ");
            scanf(" %[^\n]", editname);
            while(!name_validate(editname)) 
            {
            printf("Enter new name: ");
            scanf(" %[^\n]", editname);
            }
            strcpy(c->name,editname);
            break;
            
        case 2: 
            printf("Enter new mobile number: ");
            scanf(" %[^\n]",editphone);
                while (!number_validate(editphone) || (strcmp(editphone, c->phone) != 0 && phone_duplicate(addressBook, editphone)))

            {
            printf("Enter mobile number: ");
            scanf(" %[^\n]", editphone);
            }
           strcpy(c->phone, editphone);
          break;
            

            
        case 3: 
            printf("Enter new email: ");
            scanf(" %[^\n]",editemail);
            while (!email_validate(editemail) || (strcmp(editemail, c->email) != 0 && email_duplicate(addressBook, editemail))) 
            {
              printf("Enter new email id: ");
            scanf(" %[^\n]", editemail);
           
            }
            
            strcpy(c->email,editemail);
            break;
            
        case 4: 
            printf("Enter new name: ");
            scanf(" %[^\n]", editname);
            while(!name_validate(editname)) {
               printf("Enter new name: ");
            scanf(" %[^\n]", editname);
            }
            strcpy(c->name, editname);
            
            printf("Enter new mobile number: ");
            scanf(" %[^\n]", editphone);
            while(!number_validate(editphone)||phone_duplicate(addressBook,editphone)) {
                printf("Enter new phone number: ");
            scanf(" %[^\n]", editphone);
            }
            
            strcpy(c->phone, editphone);
            
            printf("Enter new email: ");
            scanf(" %[^\n]", editemail);
            while(!email_validate(editemail)||email_duplicate(addressBook,editemail)) {
             printf("Enter new email id: ");
            scanf(" %[^\n]", editemail);
            }
            strcpy(c->email, editemail);
            break;  
          
            
        default:
            printf("Invalid option. No changes made.\n");
            }
            
    printf("Contact updated successfully!\n");
    printf("\nUpdated contact details:\n");
    printf("Name: %s\n", c->name);
    printf("Phone: %s\n", c->phone);
    printf("Email: %s\n", c->email);

    if(asktocontinue("Edit contact:"))
    {
        editContact(addressBook);
    }
    else
    {
        printf("Returning to main menu...\n");
    }
}




void deleteContact(AddressBook *addressBook)

{
    int option;
    char searchTerm[100];
    
    printf("Search contact to delete by: 1-Name, 2-Phone, 3-Email: ");
    scanf("%d", &option);
    getchar(); 
    
    
    if(option<1 || option>3)
    {
        printf("Invalid option\n");
        return;
    }
    int index = searchandselectContact(addressBook, option);
    if(index == -1)
    {
        return; 
    }
    printf("\nCurrent contact details:\n");
    printf("Name: %s\n", addressBook->contacts[index].name);
    printf("Phone: %s\n", addressBook->contacts[index].phone);
    printf("Email: %s\n", addressBook->contacts[index].email);
    
    
    char confirm;
    printf("\nAre you sure you want to delete this contact? (y/n): ");
    scanf(" %c", &confirm);
    
    if(confirm == 'y' || confirm == 'Y')
    {
        
        for(int i = index; i < addressBook->contactCount - 1; i++)
        {
            addressBook->contacts[i] = addressBook->contacts[i + 1];
        }
        
        addressBook->contactCount--;
       
        printf("Contact deleted successfully!\n");
    }
    else
    {
        printf("Deletion cancelled.\n");
    }
    if(asktocontinue("Delete contact:"))
    {
        deleteContact(addressBook);
    }
    else
    {
        printf("Returning to main menu...\n");
    }
   
}

   
